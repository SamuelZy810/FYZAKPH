// prva verzia           2023-03-27
// najnovsie editovanie  2023-04-17
// martin.konopka@stuba.sk  UJFI, FEI STU v Bratislave

//==============================================================================
// Tento program generuje náhodne zaciatočne suradnice gul. Robi to tak, ze
// najprv rozdeli celu krabicu alebo stol na isty pocet rovnakych dlazdic
// (t. j. buniek). Potom do kazdej bunky vlozi max. jednu gulu na nahodne miesto
// dlazdice. Pocet vytvorenych buniek, napr. v 3D ich je
//     NGrid[1]*NGrid[2]*NGrid[3] ,
// je vacsi alebo rovny ako dany pocet gul.
// Aby nebolo generovanych prilis vela zbytocnych buniek, vyzera algoritmus na
// vytvaranie buniek pomerne zlozito. Ale stacilo by ho slovne vysvetlit,
// a bol by jasny. Aspon strucne: Podstatnou castou je cyklus while ():
// Podla daneho poctu gul rozdli krabicu na potrebny (a zvycajne o cosi vacsi)
// pocet rovnakych buniek. Aby nedelil krabicu zbytocne vela krat (na zbytocne
// vela buniek), po vybaveni zdvojnasobovania poctu buniek pozdlz kazdej
// kartezianskej osi (ic) zistuje, ci uz je buniek dost. (Teda nie az ked by
// vybavil vsetkych NDim osi.
// Dalo by sa to spravit este lepsie - nie zdvojnasobovat, ale nejako miernejsie
// zvacsovat pocet dlazdic.
//==============================================================================

#include <stdio.h>
#include <stdlib.h>
#include <float.h>
#include "pocty.h"

//-----------------------------------------------------------------------------------------
// rand() je funkcia zo stdlib. Vracia celociselne hodnoty z mnoziny {0, 1, ..., RAND_MAX}.
// NAHODNE01 bude realne z intervalu <0, 1>.
//-----------------------------------------------------------------------------------------
#define NAHODNE01  ((double)rand()/RAND_MAX)


int zac_sur(const double Lstol[1+NDim], const double extrad, double sur[1+NGul][1+NDim])
{
    int sucin(const int pole[1+NDim]);
    double Lmin = DBL_MAX;
    double Lmax = DBL_MIN;
    for (int ic = 1; ic <= NDim; ic++) {
        if (Lstol[ic] < Lmin) Lmin = Lstol[ic];
        if (Lstol[ic] > Lmax) Lmax = Lstol[ic];
    }
    int NGrid[1+NDim];
    //------------------------------------------------------------------------
    // Najprv vyrobime isty zaciatocny pocet rovnakych fiktivnych dlazdic
    // (buniek), podla moznosti pomerom stran co najblizsich stvorcom (pre 2D)
    // alebo kockam (pre 3D).
    //------------------------------------------------------------------------
    for (int ic = 1; ic <= NDim; ic++) NGrid[ic] = (int) (0.5 + Lstol[ic]/Lmin);
    int ic = 0;
    while (sucin(NGrid) < NGul) {
        ic++;
        NGrid[ic] *= 2;
        if (ic == NDim) ic = 0;
    }
    double Ldlaz[1+NDim];
    for (int ic = 1; ic <= NDim; ic++) {
        Ldlaz[ic] = Lstol[ic]/NGrid[ic];
        fprintf(stdout, " Ldlaz[%d] = %1.10lf\n", ic, Ldlaz[ic]);
        if (Ldlaz[ic] < 2*extrad) {
            fprintf(stderr, " zac_sur(): CHYBA pri ic = %d: Dlazdica je prilis mala. Koncim.\n", ic);
            exit(2);
        }
    }
    //----------------------------------------------------------------------------
    // Potom zacneme ukladat gule na jednotlive dlazdice (do jednotlivych buniek).
    // Max. jedna gula na dlazdicu.
    //----------------------------------------------------------------------------
    int ig = 0;
    if (NDim == 1) {
        for (int idlaz1 = 0; idlaz1 < NGrid[1]; idlaz1++) {
            double ciara1 = -0.5*Lstol[1] + idlaz1 * (Lstol[1]/NGrid[1]);
            ig++;
            sur[ig][1] = ciara1 + extrad + NAHODNE01*(Ldlaz[1]-2*extrad);
            if (ig == NGul) return 0;
        }
    }
    else if (NDim == 2) {
        for (int idlaz1 = 0; idlaz1 < NGrid[1]; idlaz1++) {
            double ciara1 = -0.5*Lstol[1] + idlaz1 * (Lstol[1]/NGrid[1]);
            for (int idlaz2 = 0; idlaz2 < NGrid[2]; idlaz2++) {
                double ciara2 = -0.5*Lstol[2] + idlaz2 * (Lstol[2]/NGrid[2]);
                ig++;
                sur[ig][1] = ciara1 + extrad + NAHODNE01*(Ldlaz[1]-2*extrad);
                sur[ig][2] = ciara2 + extrad + NAHODNE01*(Ldlaz[2]-2*extrad);
                if (ig == NGul) return 0;
            }
        }
    }
    else if (NDim == 3) {
        for (int idlaz1 = 0; idlaz1 < NGrid[1]; idlaz1++) {
            double ciara1 = -0.5*Lstol[1] + idlaz1 * (Lstol[1]/NGrid[1]);
            for (int idlaz2 = 0; idlaz2 < NGrid[2]; idlaz2++) {
                double ciara2 = -0.5*Lstol[2] + idlaz2 * (Lstol[2]/NGrid[2]);
                for (int idlaz3 = 0; idlaz3 < NGrid[3]; idlaz3++) {
                    double ciara3 = -0.5*Lstol[3] + idlaz3 * (Lstol[3]/NGrid[3]);
                    ig++;
                    sur[ig][1] = ciara1 + extrad + NAHODNE01*(Ldlaz[1]-2*extrad);
                    sur[ig][2] = ciara2 + extrad + NAHODNE01*(Ldlaz[2]-2*extrad);
                    sur[ig][3] = ciara3 + extrad + NAHODNE01*(Ldlaz[3]-2*extrad);
                    if (ig == NGul) return 0;
                }
            }
        }
    }
    else {
        fprintf(stderr, " zac_sur(): CHYBA:  NDim = %d nespravna alebo nepodporovana hodnota. Koncim.\n\n", NDim);
        exit(2);
    }
    return 1;
}


int sucin(const int pole[1+NDim])
{
    int vys = pole[1];
    for (int ii = 2; ii <= NDim; ii++) vys *= pole[ii];
    return vys;
}
