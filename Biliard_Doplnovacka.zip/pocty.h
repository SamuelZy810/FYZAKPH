#define NGul 10
#define NDim 2
