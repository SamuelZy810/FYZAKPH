// prva neuplna verzia   2022-04-30
// prva uplna verzia     2022-05-08
// najnovsie editovanie  2023-04-17
// martin.konopka@stuba.sk  UJFI, FEI STU v Bratislave

#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>
#include <stdio.h>
#include <stdlib.h>
#include <float.h>
#include <math.h>

//const int NGul = 10;  // Takto to nejde, lebo pouzivame staticku alokaciu
//const int NDim = 2;  // a globalne deklarovane a alokovane polia.
// Elegantnou alternativou by bola dynamicka alokacia.

#include "pocty.h"

//-----------------------------------------------------------------------------------------
// rand() je funkcia zo stdlib. Vracia celociselne hodnoty z mnoziny {0, 1, ..., RAND_MAX}.
// NAHODNEm1p1 bude realne z intervalu <-1, 1>.
//-----------------------------------------------------------------------------------------
#define NAHODNEm1p1  (-1.0 + 2*(double)rand()/RAND_MAX)

double Lstol[1+NDim];
double posunDalej, ZorUhY;  // pre kozmicky biliard
double sur[1+NGul][1+NDim];
double vel[1+NGul][1+NDim];

//const double polomer = 0.03075; // naozajstny polomer kazdej z gul
//const double extrad = 0.032;    // Pomocna hodnota (extended radius) o kusok vacsia nez polomer,
                                  // aby sme pomocou nej zabezpecili dostatocne odstupy na zaciatku.

const double polomer = 0.10;  // Pripadne skusme vacsie plomery gul nez sa naozaj pouzivaju,
const double extrad = 0.11;   // lebo to moze pomoct pri odladovani programu.

// Prilis kratsi casovy krok ako 25 ms asi nie, lebo nebude stihat hardver.
// Ale zasa pri 25 to seka ...
const int icaskrok = 20;  // v milisekundach
const double dt = 0.020;  // aj toto je v ms
double Lvacsie;  // pomocna dlzkova skala pre grafiku


double skalsuc(const double vec1[1+NDim], const double vec2[1+NDim])
{
    double suma = 0.0;
    for (int cart = 1; cart <= NDim; cart++) suma += vec1[cart]*vec2[cart];
    return suma;
}

void aktualizuj(const int iusek)
{
    extern double dalsia_zrazka(const double PosNow[1+NGul][1+NDim], const double VelNow[1+NGul][1+NDim],
                                int *OdrGula, int *OdrCart, int *igzr, int *jgzr);

    static int OdrGula, OdrCart, igzr, jgzr, PUsekov;  // Trieda static, aby boli hodnoty zapamatane aj medzi jednotlivymi
    static double dtloc;          // volaniami funkcie aktualizuj. Inak by sme museli tieto parametre deklarovat globalne.
    const double MaleKladneCislo = 100*DBL_EPSILON;

    if (iusek == 1) {
        double CasZr = dalsia_zrazka(sur, vel, &OdrGula, &OdrCart, &igzr, &jgzr);
        PUsekov = 1 + (int)(CasZr/dt);
        dtloc = CasZr/PUsekov;  // icaskrok neriesme; vznikne len nebadatelna odchylka
    }
    for (int ig = 1; ig <= NGul; ig++) for (int ic = 1; ic <= NDim; ic++) sur[ig][ic] += vel[ig][ic]*dtloc;
    glutPostRedisplay();
    if (iusek == PUsekov) {
        //-----------------------------------------------------------------------------------------------------
        // Prave sme dosli po okamih nejakej zrazky v sustave.
        // Preto upravime rychlosti gul (alebo gule), ktorych sa to tyka,
        // a zresetujeme pocitanie casovych usekov medzi po sebe nasledujucimi zrazkami.
        // Teda nastavime posledny parameter v glutTimerFunc na 1.
        //-----------------------------------------------------------------------------------------------------
        if (OdrCart > 0) { // zrazka jednej gule so stenou
            vel[OdrGula][OdrCart] *= -1;
            glutTimerFunc(icaskrok, aktualizuj, 1);  // reset hodnoty iusek
        }
        else if (OdrCart == 0) { // zrazka dvoch gul navzajom; ich indexy su igzr, jgzr  (i-ta, j-ta)
            double uij[1+NDim], vij[1+NDim], dvi[1+NDim];
            for (int ic = 1; ic <= NDim; ic++) uij[ic] = sur[jgzr][ic]-sur[igzr][ic];  // Toto je zatial len vektor rij.
            double rijsq = skalsuc(uij, uij);  // Toto je naozaj  rij^2  a ma to byt rovne (2*polomer)^2.
            if (fabs(rijsq-4*polomer*polomer) > MaleKladneCislo) {
                fprintf(stdout, " aktualizuj(): CHYBA: |rijsq-4*polomer*polomer| = %1.14le  je prilis velka odchylka.\n",
                        fabs(rijsq-4*polomer*polomer));
            }
            for (int ic = 1; ic <= NDim; ic++) uij[ic] /= (2*polomer);  // Uz je to teraz naozaj jednotkovy vektor.
            for (int ic = 1; ic <= NDim; ic++) vij[ic] = DOPLNTE; // (rozdiel rychlosti j-tej a i-tej gule, kart. zlozka ic)
            for (int ic = 1; ic <= NDim; ic++) dvi[ic] = uij[ic]*skalsuc(uij, vij);  // zmena rychlosti i-tej gule pri zrazke
            for (int ic = 1; ic <= NDim; ic++) vel[igzr][ic] += DOPLNTE;
            for (int ic = 1; ic <= NDim; ic++) vel[jgzr][ic] -= DOPLNTE;
            glutTimerFunc(icaskrok, aktualizuj, 1);  // reset hodnoty iusek
        }
        else {
            fprintf(stderr, " aktualizuj(): Chyba: Zrazka nebola spravne urcena. Koncim.\n\n");
            exit(9);
        }
    }
    else glutTimerFunc(icaskrok, aktualizuj, iusek+1);
}

void obsluhaResize(int sirka, int vyska)
{
    glViewport(0, 0, sirka, vyska);
    glMatrixMode(GL_PROJECTION); 
    glLoadIdentity();
    if (sirka == 0) sirka++;
    if (vyska == 0) vyska++;
    const double    pomstr = ((double)vyska)/sirka;
    if (NDim <= 2) {
        //const double invpomstr = ((double)sirka)/vyska;
        gluOrtho2D(-0.6*Lvacsie, 0.6*Lvacsie , -0.6*Lvacsie*pomstr, 0.6*Lvacsie*pomstr);
        //---------------------------------------------------------------------------------------
        // pouzit (zakomentovane), ak chceme, aby sa 2D scena vzdy spravne zmestila na obrazovku.
        //---------------------------------------------------------------------------------------
        /*
        const double    pomstr = ((double)vyska)/sirka;
        const double invpomstr = ((double)sirka)/vyska;
        if (sirka >= vyska)
            gluOrtho2D(-0.5*Lvacsie*invpomstr, 0.5*Lvacsie*invpomstr , -0.5*Lvacsie, 0.5*Lvacsie);
        else
            gluOrtho2D(-0.5*Lvacsie, 0.5*Lvacsie , -0.5*Lvacsie*pomstr, 0.5*Lvacsie*pomstr);
        */
    }
    else {
        const double invpomstr = ((double)sirka)/vyska;
         const double dnear = 0.0*Lstol[3] + posunDalej;  // Toto su len dost provizorne nastavenia,
         const double dfar  = 1.0*Lstol[3] + posunDalej;  // ale funguje to.
        gluPerspective(ZorUhY, invpomstr, dnear, dfar);
    }
}

void kresliObjekty2D()
{
    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_MODELVIEW);
    //================
    // biliardovy stol
    //================
    glLoadIdentity();
    glColor3d(0.0, 1.0, 0.0);  // zelena farba stola
    glScaled(Lstol[1], Lstol[2], 1.0);
    glRectd(-0.5, -0.5, 0.5, 0.5);
    //====================================================
    // gula (zobrazena ako kruh, vlastne ako mnohouholnik)
    //====================================================
    const int PLucov = 36;
    for (int ig = 1; ig <= NGul; ig++) {
        glColor3d(1-(double)(ig-1)/NGul, 0.0, (double)(ig-1)/NGul);  // farba gule
        glLoadIdentity();
        glTranslated(sur[ig][1], sur[ig][2], 0.0); // Najprv glTranslated,
        glScaled(polomer, polomer, 1.0); // potom glScaled.
        glBegin(GL_TRIANGLE_FAN);
        //----------------------------------------------------------------
        // Stred kruhu najprv umiestnime do pociatku suradnicovej sustavy.
        // Nasledne kruh posunieme na fyzikalne spravne miesto
        // (to spravi vyssie uvedena funkcia glTranslated)
        // a natiahneme na pozadovany polomer (pomocou glScaled).
        //----------------------------------------------------------------
        TU_NAKRESLITE_KRUH O POLOMERE 1 SO STREDOM V POCIATKU
        glEnd();
    }
    glutSwapBuffers();
} 

void kresliObjekty3D()
{
    glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_MODELVIEW);
    //========
    // krabica
    //========
    glLoadIdentity();
    glColor3d(0.0, 1.0, 0.0);
    glTranslated(0.0, 0.0, posunDalej);
    glScaled(Lstol[1], Lstol[2], Lstol[3]);
    glBegin(GL_LINES);

    // ciary v smere osi x
    glVertex3d(-0.5, -0.5, -0.5);
    glVertex3d(+0.5, -0.5, -0.5);

    glVertex3d(-0.5, -0.5, +0.5);
    glVertex3d(+0.5, -0.5, +0.5);

    glVertex3d(-0.5, +0.5, -0.5);
    glVertex3d(+0.5, +0.5, -0.5);

    glVertex3d(-0.5, +0.5, +0.5);
    glVertex3d(+0.5, +0.5, +0.5);

    // ciary v smere osi y
    DOPLNTE

    // ciary v smere osi z
    glVertex3d(-0.5, -0.5, -0.5);
    glVertex3d(-0.5, -0.5, +0.5);

    glVertex3d(-0.5, +0.5, -0.5);
    glVertex3d(-0.5, +0.5, +0.5);

    glVertex3d(+0.5, -0.5, -0.5);
    glVertex3d(+0.5, -0.5, +0.5);

    glVertex3d(+0.5, +0.5, -0.5);
    glVertex3d(+0.5, +0.5, +0.5);

    glEnd();
    //====================================================
    // gula (zobrazena ako kruh, vlastne ako mnohouholnik)
    // Sem by sa vsak viac hodila naozaj gula, nie kruh.
    //====================================================
    const int PLucov = 36;
    for (int ig = 1; ig <= NGul; ig++) {
        glColor3d(1-(double)(ig-1)/NGul, 0.0, (double)(ig-1)/NGul);  // farba gule
        glLoadIdentity();
        glTranslated(sur[ig][1], sur[ig][2], sur[ig][3] + posunDalej); // Najprv glTranslated,
        glScaled(polomer, polomer, 1.0);                               // potom glScaled.
        glBegin(GL_TRIANGLE_FAN);
        TU_NAKRESLITE_KRUH O POLOMERE 1 SO STREDOM V POCIATKU
        glEnd();
    }
#if 0
    // NEUSPESNY POKUS NAKRESLIT GULU NAMIESTO KRUHU.
    // KTO CHCE, MOZE TO SKUSIT SPRAVIT DOBRE.
    // MOZNO BY TO CHCELO UPRAVU AJ NA DALSICH MIESTACH KODU.
    // TAK AKO TO JE, BY TO KRESLILO ZDANLIVO NEJAKE PLOSKACE.
    for (int ig = 1; ig <= NGul; ig++) {
        glColor3d(1-(double)(ig-1)/NGul, 0.0, (double)(ig-1)/NGul);  // farba gule
        glLoadIdentity();
        glTranslated(sur[ig][1], sur[ig][2], sur[ig][3] + posunDalej); // Najprv glTranslated,
        glScaled(polomer, polomer, 1.0);                               // potom glScaled.
        glutSolidSphere(polomer,10,10);
    }
#endif
    glutSwapBuffers();
} 


int main(int argc, char **argv)
{
    int zac_sur(const double Lstol[1+NDim], const double extrad, double sur[1+NGul][1+NDim]);

    if (NDim < 2 || NDim > 3) {   // Dalo by sa dorobit, aby fungovalo aj NDim = 1.
        fprintf(stderr, " CHYBA:  NDim = %d je nespravne alebo nie uplne implementovane.\n\n", NDim);
        exit(1);
    }
    if (extrad <= polomer) {
        fprintf(stderr, " CHYBA:  extrad = %1.10lf (\"extended radius\") je prilis male.\n", extrad);
        fprintf(stderr, "         Musi byt vacsie nez %1.10lf. Koncim.\n\n", polomer);
        exit(1);
    }
    //====================================================
    // rozmery stola, mozu by aj pre kozmicky biliard v 3D
    //====================================================
    Lstol[1] = 2.84;  // dlzka stola
    Lstol[2] = 1.42;  // sirka stola
    if (NDim == 3) {
        Lstol[3] = 2.00;  // vyska ,stola', pre nas vizualne hlbka
        posunDalej = -1.50;  // Za obrazovkou je z < 0 .
        ZorUhY = 120.0;
    }
    //===============================
    // Zvol zaciatocne rychlosti gul.
    //===============================
    DOPLNTE - napraktickejsie nahodne, aj kladne, aj zaporne, rozumne velke
    //===============================
    // Zvol zaciatocne suradnice gul.
    //===============================
    if (zac_sur(Lstol, extrad, sur) != 0) {
        fprintf(stdout, " CHYBA pri generovani zaciatocnych suradnic.\n\n");
        exit(3);
    }
    //for (int ig = 1; ig <= NGul; ig++) for (int ic = 1; ic <= NDim; ic++)
    //    fprintf(stdout, " sur[%d][%d] = %20.10lf\n", ig, ic, sur[ig][ic]);
    //=======================================================
    // globalne deklarovana pomocna dlzkova skala pre grafiku
    //=======================================================
    Lvacsie = fmax(Lstol[1], Lstol[2]);
    //===========================================
    // Inicializacie pre grafiku a hlavny cyklus.
    //===========================================
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_RGBA);  // nie je nutne pisat
    glutInitDisplayMode(GLUT_DOUBLE);

    glutInitWindowSize(1250, 750);
    glutInitWindowPosition(0, 0);
    glutCreateWindow("OpenGL: biliard");
    glClearColor(1.0, 1.0, 1.0, 0.3);  // biela farba pozadia

    if (NDim <= 2) glutDisplayFunc(kresliObjekty2D);
    else           glutDisplayFunc(kresliObjekty3D);
    glutReshapeFunc(obsluhaResize);
    //---------------------------------------------------------------------
    // Posledny parameter glutTimerFunc() bude oznacovat casovy krok (usek)
    // medzi dvoma po sebe nasledujucimi zrazkami. Zvolme si, nech toto
    // indexovanie casovych usekov zacina od 1. Takze uz tu to treba
    // nastavit na 1. Tato jednotka bude aj siganizovat, ze treba spravit
    // analyzu, kedy v sustave nastane dalsia zrazka.
    //---------------------------------------------------------------------
    glutTimerFunc(icaskrok, aktualizuj, 1);

    glutMainLoop();

    return 0;
}
